package mc.z1gned.enchanted.util;

public interface MobEnchantInterface {
    MobEnchantmentAbility getEnchantAbility();

    void setEnchantAbility(MobEnchantmentAbility var1);

}
